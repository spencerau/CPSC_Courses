README

Spencer Au
ID: 002385256
spau@chapman.edu
CPSC 350 - Section 2
PA1

Source Files:
Model.h and Model.cpp
Translator.h and Translator.cpp
FileProcessor.h and FileProcessor.cpp
main.cpp

References:
https://www.learncpp.com/
https://cplusplus.com/
https://en.cppreference.com/w/
https://github.com/connectaman/Cpp-Notes-and-Programs/blob/master/String/String.md
https://www.geeksforgeeks.org/command-line-arguments-in-c-cpp/
https://www.geeksforgeeks.org/stringstream-c-applications/
https://www.geeksforgeeks.org/removing-punctuations-given-string/
https://html.com/#Creating_Your_First_HTML_Webpage
https://www.w3schools.com/htmL/default.asp
https://www.tutorialspoint.com/cplusplus/cpp_files_streams.htm
https://www.positioniseverything.net/html-italics/
https://stackoverflow.com/questions/5343173/returning-to-beginning-of-file-after-getline
https://stackoverflow.com/questions/2310939/remove-last-character-from-c-string

People:
Ammar Askar
Kevin Nagar

Instructions:
To Compile: g++ Model.cpp Translator.cpp FileProcessor.cpp main.cpp -o ".exe"
To Run: ./".exe" fileName.txt fileName.html