README

Spencer Au
ID: 002385256
spau@chapman.edu
CPSC 350 - Section 2
PA2

Source Files:
MonoStack.h
SpeakerView.h and SpeakerView.cpp
main.cpp

References:
https://www.learncpp.com/
https://cplusplus.com/
https://en.cppreference.com/w/
https://www.geeksforgeeks.org/

https://cplusplus.com/forum/beginner/229720/
https://stackoverflow.com/questions/21334173/read-from-file-in-c-till-end-of-line
https://www.codeproject.com/Articles/48575/How-to-Define-a-Template-Class-in-a-h-File-and-Imp

People:
Ammar Askar
Kevin Nagar
Victor Au

Instructions:
To Compile: g++ MonoStack.h SpeakerView.cpp main.cpp -o "Program Name"
To Run: ./"Program Name" inputFile