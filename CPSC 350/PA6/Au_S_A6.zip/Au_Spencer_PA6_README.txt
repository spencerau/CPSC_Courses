README

Spencer Au
ID: 002385256
spau@chapman.edu
CPSC 350 - Section 2
PA6

NOTE:
Does not calculate correct minimum distance for MST

Source Files:
ListNode.h
DblList.h
PQueue.h
WGraph.h and WGraph.cpp
main.cpp

References:
https://www.learncpp.com/
https://cplusplus.com/
https://en.cppreference.com/w/
https://www.geeksforgeeks.org/

https://lldb.llvm.org/use/map.html

https://www.geeksforgeeks.org/detect-cycle-undirected-graph/
https://www.geeksforgeeks.org/introduction-to-disjoint-set-data-structure-or-union-find-algorithm/
https://www.geeksforgeeks.org/kruskals-minimum-spanning-tree-algorithm-greedy-algo-2/


People:
Kevin Nagar


Instructions:
To Compile: g++ *.cpp -o "Program Name"
To Run: ./"Program Name" inputFile