README

Spencer Au
ID: 002385256
spau@chapman.edu
CPSC 350 - Section 2
PA4

Source Files:
ListNode.h
DblList.h
ListQueue.h
Customer.h and Customer.cpp
Window.h and Window.cpp
Office.h and Office.cpp
ServiceCenter.h and ServiceCenter.cpp
main.cpp

References:
https://www.learncpp.com/
https://cplusplus.com/
https://en.cppreference.com/w/
https://www.geeksforgeeks.org/

https://lldb.llvm.org/use/map.html

https://www.freecodecamp.org/news/string-to-int-in-c-how-to-convert-a-string-to-an-integer-example/
https://stackoverflow.com/questions/7868936/read-file-line-by-line-using-ifstream-in-c
https://www.geeksforgeeks.org/converting-strings-numbers-c-cpp/


People:
Ammar Askar - GDB/LLDB


Instructions:
To Compile: g++ *.cpp -o "Program Name"
To Run: ./"Program Name" inputFile