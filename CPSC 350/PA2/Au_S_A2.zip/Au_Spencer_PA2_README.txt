README

Spencer Au
ID: 002385256
spau@chapman.edu
CPSC 350 - Section 2
PA2

Source Files:
Player.h and Player.cpp
Level.h and Level.cpp
World.h and World.cpp
main.cpp

*Note - Program does not compile 

References:
https://www.learncpp.com/
https://cplusplus.com/
https://en.cppreference.com/w/

https://www.geeksforgeeks.org/enumerated-types-or-enums-in-c/
https://cplusplus.com/reference/cstdlib/rand/
https://cplusplus.com/reference/array/array/size/
https://www.geeksforgeeks.org/switch-statement-cc/
https://www.geeksforgeeks.org/arrays-in-c-cpp/
https://stackoverflow.com/questions/1534324/what-does-int-array-create
https://stackoverflow.com/questions/1284529/enums-can-they-do-in-h-or-must-stay-in-cpp
https://www.geeksforgeeks.org/char-vs-stdstring-vs-char-c/
https://www.hermetic-systems.com/cfunlib/arrays/arrays2.htm
https://stackoverflow.com/questions/5029840/convert-char-to-int-in-c-and-c
https://www.delftstack.com/howto/cpp/read-int-from-file-cpp/


People:
Ammar Askar - Intializing (char) Array and Online Resources related; suggested using enums

Instructions:
To Compile: g++ Player.cpp Level.cpp World.cpp main.cpp -o ".exe"
To Run: ./".exe" inputFile.txt outputFile.html